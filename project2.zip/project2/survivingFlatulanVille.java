/* ***************************************************************************
 *
 * Project:          Project 01
 * Project Name:     Flatulan
 * Main Class File:  survivingFlatulanVille
 * File:             survivingFlatulanVille.java
 * Semester:         CSC300 Spring 2021
 *
 *
 * Username:         mmccullough
 * @author           Malcolm McCullough
 * @version          0.9
 * @since            2021-01-81
 * Instructors:      McCullough
 * Section:          01
 *
 *
 * Description: Has Flatulan, City, Player, and Games classes
 * Simple game
 *  You have arrived in the walled city of Flatula, whose residents eat beans,
 *  cabbage, and hard-boiled eggs for every meal. Although they are used to
 *  the resulting effects, the odor that emanates from the Flatulans makes you
 *  woozy. Your only hope is to convert all the citizens to a diet of lean
 *  meat, lettuce, and rice.
 *
 *
 *
 * TODO
 * rewrite this code some it uses good programming practices
 * for example (not a complete list - see writeup for full list of tasks):
 *    -->separate into multiple fiels (by class),
 *    documentation for all files / classes and methods
 *           (see examples such as determineNewPosition)
 *    add exceptions: for all range value checks
 *    add failed convertion history (see writeup)
 *
 * ***************************************************************************/



/* ******************************************************************/
/*                                                                  */
/*          survivingFlatulanVille the driver Class                            */
/*                                                                  */
/* ******************************************************************/
class survivingFlatulanVille {

    ///////////////////////////////////////////////////////////////////////////
    //  main()
    ///////////////////////////////////////////////////////////////////////////
    public static void main(String argv[]) {

        String verbose = System.getProperty("Verbose");
        if (verbose != null) {
            System.err.println(": " + verbose);
            City.Verbose = true;
        }
        // Create a game
        // Use this instead to create a mini-game:   Game(7, 8, 25);
        // (int rows, int cols, int nFlatulans)

        try {
            Game g = new Game(7, 8, 25);
               // Play the game
            g.play();
         } catch (InterruptedException e) {
            System.err.println("Got interrupted...");
            System.exit(0);
         }
     
    }
}
